package Controller;

import View.EmpireMenu;


public class EmpireMenuController {
    private final EmpireMenu empireMenu;
    public EmpireMenuController(){
        empireMenu = new EmpireMenu(this);
    }

    public void run(){
    }

    public String showPopularityFactors(){
        return null;}
    public int showPopularity(){
        return 0;}
    public String showFoodList(){return null;}
    public void changeFoodRate(int rate){
    }
    public String foodRateShow(){return null;}
    public void changeTaxRate(int rate){}
    public String taxRateShow(){return null;}
    public void changeFearRate(int rate){}

}
