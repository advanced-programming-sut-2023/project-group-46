package Model;

public class Resources {
    private int gold;

    private int wheat;

    private int flour;

    private int hops;

    private int ale;

    private int stone;

    private int iron;

    private int wood;

    private int pitch;

    public int getGold() {
        return gold;
    }

    public int getWheat() {
        return wheat;
    }

    public int getFlour() {
        return flour;
    }

    public int getHops() {
        return hops;
    }

    public int getAle() {
        return ale;
    }

    public int getStone() {
        return stone;
    }

    public int getIron() {
        return iron;
    }

    public int getWood() {
        return wood;
    }

    public int getPitch() {
        return pitch;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public void setWheat(int wheat) {
        this.wheat = wheat;
    }

    public void setFlour(int flour) {
        this.flour = flour;
    }

    public void setHops(int hops) {
        this.hops = hops;
    }

    public void setAle(int ale) {
        this.ale = ale;
    }

    public void setStone(int stone) {
        this.stone = stone;
    }

    public void setIron(int iron) {
        this.iron = iron;
    }

    public void setWood(int wood) {
        this.wood = wood;
    }

    public void setPitch(int pitch) {
        this.pitch = pitch;
    }
}
