package View;

import Controller.MapMenuController;

public class MapMenu {
    private final MapMenuController mapMenuController;

    public MapMenu(MapMenuController mapMenuController) {
        this.mapMenuController = mapMenuController;
    }

    public void run() {
    }
}
