package View;

import Controller.ShopMenuController;

public class ShopMenu {
    private final ShopMenuController shopMenuController;

    public ShopMenu(ShopMenuController shopMenuController) {
        this.shopMenuController = shopMenuController;
    }
    public void run(){}
}
