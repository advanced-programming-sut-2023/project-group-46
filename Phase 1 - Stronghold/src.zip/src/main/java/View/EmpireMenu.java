package View;

import Controller.EmpireMenuController;

public class EmpireMenu {
    private final EmpireMenuController empireMenuController;

    public EmpireMenu(EmpireMenuController empireMenuController) {
        this.empireMenuController = empireMenuController;
    }
    public void run(){}
}
