package View;

import Controller.GameMenuController;

public class GameMenu {
    private final GameMenuController gameMenuController;

    public GameMenu(GameMenuController gameMenuController) {
        this.gameMenuController = gameMenuController;
    }
    public void run(){}
}