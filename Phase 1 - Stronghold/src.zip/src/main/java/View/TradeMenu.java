package View;

import Controller.TradeMenuController;

public class TradeMenu {
    private final TradeMenuController tradeMenuController;

    public TradeMenu(TradeMenuController tradeMenuController) {
        this.tradeMenuController = tradeMenuController;
    }
    public void run(){}
}
