package View;

import Controller.EditMapMenuController;

public class EditMapMenu {
    private final EditMapMenuController editMapController;

    public EditMapMenu(EditMapMenuController editMapMenuController) {
        this.editMapController = editMapMenuController;
    }

    public void run() {
    }
}
